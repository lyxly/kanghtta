/* This file is auto generated, version 1 */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#1 Tue Sep 13 18:18:41 CST 2005"
#define LINUX_COMPILE_TIME "18:18:41"
#define LINUX_COMPILE_BY "mdv"
#define LINUX_COMPILE_HOST "localhost"
#define LINUX_COMPILE_DOMAIN ""
#define LINUX_COMPILER "gcc version 3.4.3 (Mandrakelinux 10.2 3.4.3-7mdk)"
